package com.assignphonenumber.test;

import java.sql.SQLException;

import com.assignnewnumber.controller.AssignNewRandonNumber;

public class TestClass {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
	
	AssignNewRandonNumber newNum=new AssignNewRandonNumber();
	
	//System.out.println(newNum.assignNewRandomNumber());
	
	//System.out.println(newNum.alocateASpecificNumber("111-111-1111"));
	
	//System.out.println(obj.generateFirstSectionOfFirstPart());
	}

}
