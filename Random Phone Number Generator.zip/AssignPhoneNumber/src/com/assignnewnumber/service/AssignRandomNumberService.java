package com.assignnewnumber.service;

import java.sql.SQLException;

import com.assignnewnumber.delegate.AssambleRandomNumber;

public class AssignRandomNumberService {

	AssambleRandomNumber newNumber=null;
	
	public AssignRandomNumberService() throws ClassNotFoundException, SQLException
	{
		newNumber=new AssambleRandomNumber();
	}
	public String assignNewRandomNumber()
	{
		String number=null;
		try {
			number= newNumber.generateANewNumber();
			System.out.println("generated number : "+number);
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		return number;
	}
	
	public String alocateASpecificNumber(String number)
	{
		String message=null;
		
		try {
			String aloateNumber=newNumber.alocateSpecifiedNumber(number);
			if(aloateNumber!=null)
			{
				message=aloateNumber+" is assigened to you";
			}
			else
			{
				message=number+" is not updated";	
			}
			
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return message;
	}
}
