package com.assignnewnumber.helper;

import java.util.Random;

public class TrackDigits {

	
	boolean[] trackFirstDigitOfFirstPart=null;
	boolean[] trackSecondDigitOfFirstPart=null;
	boolean[] trackThirdDigitOfFirstPart=null;
	
	boolean[] trackFirstDigitOfSecondPart=null;
	boolean[] trackSecondDigitOfSecondPart=null;
	boolean[] trackThirdDigitOfSecondPart=null;
	
	boolean[] trackFirstDigitOfThirdPart=null;
	boolean[] trackSecondDigitOfThirdPart=null;
	boolean[] trackThirdDigitOfThirdPart=null;
	boolean[] trackFourthDigitOfThirdPart=null;
	

	int leftDigitsForFirstSectionOfFirstPart=9;
	int leftDigitsForSecondSectionOfFirstPart=9;
	int leftDigitsForThirdSectionOfFirstPart=9;
	
	
	int leftDigitsForFirstSectionOfSecondPart=9;
	int leftDigitsForSecondSectionOfSecondPart=9;
	int leftDigitsForThirdSectionOfSecondPart=9;
	
	int leftDigitsForFirstSectionOfThirdPart=9;
	int leftDigitsForSecondSectionOfThirdPart=9;
	int leftDigitsForThirdSectionOfThirdPart=9;
	int leftDigitsForFourthSectionOfThirdPart=9;
	
	Random singleDigitGenerator=null;
	
	public TrackDigits()
	{
		this.singleDigitGenerator=new Random();
	}
	
	
	public void disableAll()
	{
		 trackFirstDigitOfFirstPart=null;
		 trackSecondDigitOfFirstPart=null;
		 trackThirdDigitOfFirstPart=null;
		
		 trackFirstDigitOfSecondPart=null;
		 trackSecondDigitOfSecondPart=null;
		 trackThirdDigitOfSecondPart=null;
		
		 trackFirstDigitOfThirdPart=null;
		 trackSecondDigitOfThirdPart=null;
		 trackThirdDigitOfThirdPart=null;
		 trackFourthDigitOfThirdPart=null;
		

		 leftDigitsForFirstSectionOfFirstPart=9;
		 leftDigitsForSecondSectionOfFirstPart=9;
		 leftDigitsForThirdSectionOfFirstPart=9;
		
		
		 leftDigitsForFirstSectionOfSecondPart=9;
		 leftDigitsForSecondSectionOfSecondPart=9;
		 leftDigitsForThirdSectionOfSecondPart=9;
		
		 leftDigitsForFirstSectionOfThirdPart=9;
		 leftDigitsForSecondSectionOfThirdPart=9;
		 leftDigitsForThirdSectionOfThirdPart=9;
		 leftDigitsForFourthSectionOfThirdPart=9;
	}
	
	public int getAvailableFirstDigitForFirstPart()
	{
		int res=-1;
		if(this.trackFirstDigitOfFirstPart==null)
		{
			this.trackFirstDigitOfFirstPart=new boolean[9];
		}
		if(this.leftDigitsForFirstSectionOfFirstPart>0)
		{
			int getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			while(this.trackFirstDigitOfFirstPart[getSingleDigit-1])
			{
				getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			}
			this.leftDigitsForFirstSectionOfFirstPart--;
			this.trackFirstDigitOfFirstPart[getSingleDigit-1]=true;
			res= getSingleDigit;
		}
		else
		{
			this.leftDigitsForFirstSectionOfFirstPart=9;
			this.trackFirstDigitOfFirstPart=null;
		    res=-1;
		}
		return res;
	}
	
	public int getAvailableSecondDigitForFirstPart()
	{
		int res=-1;
		if(this.trackSecondDigitOfFirstPart==null)
		{
			this.trackSecondDigitOfFirstPart=new boolean[9];
		}
		if(this.leftDigitsForSecondSectionOfFirstPart>0)
		{
			int getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			while(this.trackSecondDigitOfFirstPart[getSingleDigit-1])
			{
				getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			}
			this.leftDigitsForSecondSectionOfFirstPart--;
			this.trackSecondDigitOfFirstPart[getSingleDigit-1]=true;
			res= getSingleDigit;
		}
		else
		{
			this.leftDigitsForSecondSectionOfFirstPart=9;
			this.trackSecondDigitOfFirstPart=null;
		    res=-1;
		}
		return res;
	}
	
	public int getAvailableThirdDigitForFirstPart()
	{
		int res=-1;
		if(this.trackThirdDigitOfFirstPart==null)
		{
			this.trackThirdDigitOfFirstPart=new boolean[9];
		}
		if(this.leftDigitsForThirdSectionOfFirstPart>0)
		{
			int getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			while(this.trackThirdDigitOfFirstPart[getSingleDigit-1])
			{
				getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			}
			this.leftDigitsForThirdSectionOfFirstPart--;
			this.trackThirdDigitOfFirstPart[getSingleDigit-1]=true;
			res= getSingleDigit;
		}
		else
		{
			this.leftDigitsForThirdSectionOfFirstPart=9;
			this.trackThirdDigitOfFirstPart=null;
		    res=-1;
		}
		return res;
	}
	
	public int getAvailableFirstDigitForSecondPart()
	{
		int res=-1;
		if(this.trackFirstDigitOfSecondPart==null)
		{
			this.trackFirstDigitOfSecondPart=new boolean[9];
		}
		if(this.leftDigitsForFirstSectionOfSecondPart>0)
		{
			int getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			while(this.trackFirstDigitOfSecondPart[getSingleDigit-1])
			{
				getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			}
			this.leftDigitsForFirstSectionOfSecondPart--;
			this.trackFirstDigitOfSecondPart[getSingleDigit-1]=true;
			res= getSingleDigit;
		}
		else
		{
			this.leftDigitsForFirstSectionOfSecondPart=9;
			this.trackFirstDigitOfSecondPart=null;
		    res=-1;
		}
		return res;
	}
	
	public int getAvailableSecondDigitForSecondPart()
	{
		int res=-1;
		if(this.trackSecondDigitOfSecondPart==null)
		{
			this.trackSecondDigitOfSecondPart=new boolean[9];
		}
		if(this.leftDigitsForSecondSectionOfSecondPart>0)
		{
			int getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			while(this.trackSecondDigitOfSecondPart[getSingleDigit-1])
			{
				getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			}
			this.leftDigitsForSecondSectionOfSecondPart--;
			this.trackSecondDigitOfSecondPart[getSingleDigit-1]=true;
			res= getSingleDigit;
		}
		else
		{
			this.leftDigitsForSecondSectionOfSecondPart=9;
			this.trackSecondDigitOfSecondPart=null;
		    res=-1;
		}
		return res;
	}
	public int getAvailableThirdDigitForSecondPart()
	{
		int res=-1;
		if(this.trackThirdDigitOfSecondPart==null)
		{
			this.trackThirdDigitOfSecondPart=new boolean[9];
		}
		if(this.leftDigitsForThirdSectionOfSecondPart>0)
		{
			int getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			while(this.trackThirdDigitOfSecondPart[getSingleDigit-1])
			{
				getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			}
			this.leftDigitsForThirdSectionOfSecondPart--;
			this.trackThirdDigitOfSecondPart[getSingleDigit-1]=true;
			res= getSingleDigit;
		}
		else
		{
			this.leftDigitsForThirdSectionOfSecondPart=9;
			this.trackThirdDigitOfSecondPart=null;
		    res=-1;
		}
		return res;
	}
	
	public int getAvailableFirstDigitForThirdPart()
	{
		int res=-1;
		if(this.trackFirstDigitOfThirdPart==null)
		{
			this.trackFirstDigitOfThirdPart=new boolean[9];
		}
		if(this.leftDigitsForFirstSectionOfThirdPart>0)
		{
			int getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			while(this.trackFirstDigitOfThirdPart[getSingleDigit-1])
			{
				getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			}
			this.leftDigitsForFirstSectionOfThirdPart--;
			this.trackFirstDigitOfThirdPart[getSingleDigit-1]=true;
			res= getSingleDigit;
		}
		else
		{
			this.leftDigitsForFirstSectionOfThirdPart=9;
			this.trackFirstDigitOfThirdPart=null;
		    res=-1;
		}
		return res;
	}
	public int getAvailableSecondDigitForThirdPart()
	{
		int res=-1;
		if(this.trackSecondDigitOfThirdPart==null)
		{
			this.trackSecondDigitOfThirdPart=new boolean[9];
		}
		if(this.leftDigitsForSecondSectionOfThirdPart>0)
		{
			int getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			while(this.trackSecondDigitOfThirdPart[getSingleDigit-1])
			{
				getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			}
			this.leftDigitsForSecondSectionOfThirdPart--;
			this.trackSecondDigitOfThirdPart[getSingleDigit-1]=true;
			res= getSingleDigit;
		}
		else
		{
			this.leftDigitsForSecondSectionOfThirdPart=9;
			this.trackSecondDigitOfThirdPart=null;
		    res=-1;
		}
		return res;
	}
	public int getAvailableThirdDigitForThirdPart()
	{
		int res=-1;
		if(this.trackThirdDigitOfThirdPart==null)
		{
			this.trackThirdDigitOfThirdPart=new boolean[9];
		}
		if(this.leftDigitsForThirdSectionOfThirdPart>0)
		{
			int getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			while(this.trackThirdDigitOfThirdPart[getSingleDigit-1])
			{
				getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			}
			this.leftDigitsForThirdSectionOfThirdPart--;
			this.trackThirdDigitOfThirdPart[getSingleDigit-1]=true;
			res= getSingleDigit;
		}
		else
		{
			this.leftDigitsForThirdSectionOfThirdPart=9;
			this.trackThirdDigitOfThirdPart=null;
		    res=-1;
		}
		return res;
	}
	public int getAvailableFourthDigitForThirdPart()
	{
		int res=-1;
		if(this.trackFourthDigitOfThirdPart==null)
		{
			this.trackFourthDigitOfThirdPart=new boolean[9];
		}
		if(this.leftDigitsForFourthSectionOfThirdPart>0)
		{
			int getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			while(this.trackFourthDigitOfThirdPart[getSingleDigit-1])
			{
				getSingleDigit=singleDigitGenerator.nextInt(9)+1;
			}
			this.leftDigitsForFourthSectionOfThirdPart--;
			this.trackFourthDigitOfThirdPart[getSingleDigit-1]=true;
			res= getSingleDigit;
		}
		else
		{
			this.leftDigitsForFourthSectionOfThirdPart=9;
			this.trackFourthDigitOfThirdPart=null;
		    res=-1;
		}
		return res;
	}	
}
