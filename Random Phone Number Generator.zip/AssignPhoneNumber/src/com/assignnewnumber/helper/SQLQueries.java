package com.assignnewnumber.helper;

public class SQLQueries {

	public static String isPresentNumberInFirstPart="select firstpart_id from firstpart where firstnumber=?";
	public static String isPresentNumberInSecondPart="select secondpart_id from Secondpart where secondnumber=?";
	public static String isPresentNumberInThirdPart="select thirdpart_id from Thirdpart where thirdnumber=?";

    public static String insertInFirsttable="insert into firstPart(firstnumber) values (?)";
    public static String insertInSecondtable="insert into SecondPart(Secondnumber,firstpart_id) values (?,?)";
    public static String insertInThirdtable="insert into thirdPart(thirdnumber,secondpart_id) values (?,?)";

    public static String getAvailableNumbersInThirdTable="select thirdnumber from thirdpart where thirdnumber >= ? and secondpart_id=?";
    public static String getAvailableNumbersInFirstTable="select firstnumber from firstpart where firstnumber >= ?";
    public static String getAvailableNumbersInSecondTable="select secondnumber from secondpart where secondnumber >= ?";
    
    public static String getNumberIDFromFirstPart="select firstpart_id from firstpart where firstnumber=?";
    public static String getNumberIDFromSecondPart="select secondpart_id from secondpart where secondnumber=?";
    public static String getNumberIDFromThirdPart="select thirdpart_id from thirdpart where thirdnumber=?";
}
