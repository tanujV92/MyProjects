package com.assignnewnumber.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    
	static Connection con=null;

    public static Connection getConnection() throws ClassNotFoundException, SQLException
	{
    	
    	Class.forName("org.postgresql.Driver");
    	con = DriverManager.getConnection(
    	   "jdbc:postgresql://localhost:5432/randomphonenumber","tanuj", "tanuj");
	  return con;  	
	}
	
    public static void closeConnection() throws SQLException
    {
    	con.close();
    }
}
