package com.assignnewnumber.delegate;

import java.sql.SQLException;
import java.util.Random;

import com.assignnewnumber.dao.AssignNewRandomNumberDao;
import com.assignnewnumber.helper.TrackDigits;

public class AssambleRandomNumber {

	AssignRandomNumberDelegate generator=null;
	AssignNewRandomNumberDao chckWithDB=null;
	Random rndmNum=null;
	TrackDigits track=null;
	public AssambleRandomNumber() throws ClassNotFoundException, SQLException
	{
	  generator=new AssignRandomNumberDelegate();	
	  chckWithDB=new AssignNewRandomNumberDao();
	  track=new TrackDigits();
	}
	
	/*private void insertNumbersInDBFromFirst(int first,int second,int third) throws ClassNotFoundException, SQLException
	{
		if(chckWithDB.insertFromFirstTable(first, second, third))
		{
			System.out.println("Inserted through first table");
		}
		else
		{
			System.out.println("Notinserted from first table");
		}
	}
	
	private void insertNumbersInDBFromSecond(int first,int second,int third) throws ClassNotFoundException, SQLException
	{
		if(chckWithDB.insertFromSecondTable(first, second, third))
		{
			System.out.println("Inserted through Second table");
		}
		else
		{
			System.out.println("Notinserted from Second table");
		}
	}
	
	private void insertNumbersInDBFromThird(int first,int second,int third) throws ClassNotFoundException, SQLException
	{
		if(chckWithDB.insertFromThirdTable(first, second, third))
		{
			System.out.println("Inserted through Third table");
		}
		else
		{
			System.out.println("Notinserted from Third table");
		}
	}
	
	public String generateANewNumber() throws ClassNotFoundException, SQLException
	{
		return generateNumber();
	}
	
	
	
	
	private String generateNewValuesForSecondPart() throws SQLException
	{
		
		int second=generator.assignSecondRandonNumber();
		String secondVal=generateSecondNumber(second);
		if(secondVal!=null)
		{
			return secondVal;
		}
		else
		{
			if(second>0)
			{
				while(second!=0)
				{
					boolean[] chckValsFirstDigit=new boolean[9];
					boolean[] chckValsSecondDigit=new boolean[9];
					boolean[] chckValsThirdDigit=new boolean[9];
					
					
					int digitsLeft=9;
			//		chckVals[(second%10)-1]=true;
					digitsLeft--;
					second/=100;
					int rndVal=(rndmNum.nextInt(9)+1);
					int second_val=-1;
					while(digitsLeft>0&&!chckVals[rndVal])
					{
						int rndDigit=(rndmNum.nextInt(9)+1);
						second_val=second*10+rndVal+rndDigit;
						break;
					}
				}
			}
			else
			{
				return null;
			}
		}
	}
	
	private String generateSecondNumber(int second) throws SQLException
	{
		int ifAvailable=chckWithDB.isPresentInSecondPart(second);
		if(ifAvailable>0)
		{
			int third=generator.assignThirdRandonNumber();
			int availableThirdNumber=getAvailableNumber(third, 2);
			if(availableThirdNumber>0)
			{
				return convertIntToString(second)+"-"+convertIntToString(availableThirdNumber);
			}
			else
			{
				return null;
			}
		}
		else
		{
			int third=generator.assignThirdRandonNumber();
			return convertIntToString(second)+"-"+convertIntToString(third);
			
		}
	}
	
	private String generateNumber() throws SQLException, ClassNotFoundException
	{
		int first=generator.assignFirstPartRandomNumber();
		int second=generator.assignSecondRandonNumber();
		int third=generator.assignThirdRandonNumber();
		
		int first_id=chckWithDB.isPresentInFirstPart(first);
		if(first_id>0)
		{
			int second_id=chckWithDB.isPresentInSecondPart(second);
			if(second_id>0)
			{
				int third_id=chckWithDB.isPresentInThirdPart(third);
				if(third_id>0)
				{
					int thirdNum=getAvailableNumber(third,0);
				  	if(thirdNum>0)
				  	{
				  		insertNumbersInDBFromThird(first, second, thirdNum);
				  		return convertIntToString(first)+"-"+convertIntToString(second)+"-"+convertIntToString(thirdNum);
				  	}
				  	else
				  	{
				  		return null;
				  	}
				}
				else
				{
					insertNumbersInDBFromThird(first, second, third);
					return convertIntToString(first)+"-"+convertIntToString(second)+"-"+convertIntToString(third);
				}
			}
			else
			{
				insertNumbersInDBFromSecond(first, second, third);
				return convertIntToString(first)+"-"+convertIntToString(second)+"-"+convertIntToString(third);
			}
		}
		else
		{
			insertNumbersInDBFromFirst(first, second, third);
			return convertIntToString(first)+"-"+convertIntToString(second)+"-"+convertIntToString(third);
		}
	}
	
	public int getAvailableNumber(int number,int ind) throws SQLException
	{
		int num=-1;
		boolean[] vals=new boolean[9];
		
		int val=(number/10)*10+1;
		
		int[] nums=chckWithDB.getAvalilableNumbers(ind, val);
		System.out.println(Arrays.toString(nums));
		
		int index=0;
		while(index<10&&nums[index]!=0)
		{
			System.out.println("Here");
			vals[((nums[index]%10)-1)]=true;
			index++;
		}
		System.out.println(Arrays.toString(vals));
		for(int i=0;i<9;i++)
		{
			if(!vals[i])
			{
				num=(val/10)*10+(i+1);
				break;
			}
		}
		return num;
	}
	
	private int countDigits(int num)
	{
		int count=0;
		while(num!=0)
		{
			count++;
		    num/=10;
		}
		return count;
	}
	*/
	private String convertIntToString(int num)
	{
		return Integer.toString(num);
	}
	
	public String alocateSpecifiedNumber(String number) throws NumberFormatException, SQLException, ClassNotFoundException
	{
		String[] numbs=number.split("-");
		if(checkNumberIfAvailable(numbs))
		{
			return generateANewNumber();
		}
		else
		{
			int firstId=chckWithDB.insertNumberInFirstTable(Integer.parseInt(numbs[0]));
		    int secondId=chckWithDB.insertNumberInSecondTable(Integer.parseInt(numbs[1]), firstId);
		    int thirdId=chckWithDB.insertNumberInThirdTable(Integer.parseInt(numbs[2]), secondId);
		    if(firstId>0&&secondId>0&&thirdId>0)
		    {
		    	return number;	
		    }
		    else
		    {
		    	return null;
		    }
		}
	}
	
	private boolean checkNumberIfAvailable(String[] numbs) throws NumberFormatException, SQLException
	{
		int firstId=chckWithDB.isPresentInFirstPart(Integer.parseInt(numbs[0]));
		if(firstId>0)
		{
			int secondId=chckWithDB.isPresentInSecondPart(Integer.parseInt(numbs[1]));
			if(secondId>0)
			{
				int thirdId=chckWithDB.isPresentInThirdPart(Integer.parseInt(numbs[2]));
				if(thirdId>0)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	
	public String generateANewNumber() throws ClassNotFoundException, SQLException
	{
		String num=generateFirstSectionOfFirstPart();;
		if(num!=null)
		{
			track.disableAll();
		}
		return num;
	}
	
	
	private String generateFirstSectionOfFirstPart() throws SQLException, ClassNotFoundException
	{
		int firstDigit=track.getAvailableFirstDigitForFirstPart();
		if(firstDigit>0)
		{
			String value=generateSecondSectionOfFirstPart(firstDigit);
			if(value!=null)
			{
				return value;
			}
			else
			{
				return generateFirstSectionOfFirstPart();
			}
		}
		else
		{
			return null;
		}
	}
	
	private String generateSecondSectionOfFirstPart(int val) throws SQLException, ClassNotFoundException
	{
		int secondDigit=track.getAvailableSecondDigitForFirstPart();
		if(secondDigit>0)
		{
			int chckVal=val*10+secondDigit;
			String value=generateThirdSectionOfFirstPart(chckVal);
			if(value!=null)
			{
				return value;
			}
			else
			{
				return generateSecondSectionOfFirstPart(val);
			}
		}
		else
		{
			return null;
		}
	}
	
	private String generateThirdSectionOfFirstPart(int val) throws SQLException, ClassNotFoundException
	{
		int thirdDigit=track.getAvailableThirdDigitForFirstPart();
		if(thirdDigit>0)
		{
			int chckvalue=val*10+thirdDigit;
			int getId=chckWithDB.isPresentInFirstPart(chckvalue);
			if(getId>0)
			{
				String value=generateFirstSectionOfSecondPart(getId);
				if(value!=null)
				{
					return convertIntToString(chckvalue)+"-"+value;
				}
				else
				{
					return generateThirdSectionOfFirstPart(getId);
				}	
			}
			else
			{
				int first=chckvalue;
				int second=generator.assignSecondRandonNumber();
				int third=generator.assignThirdRandonNumber();
				System.out.println("generated values : "+first+" "+second+" "+third);
				chckWithDB.insertFromFirstTable(first, second, third);
				return convertIntToString(first)+"-"+convertIntToString(second)+"-"+convertIntToString(third);
			}
		}
		else
		{
			return null;
		}
	}
	
	private String generateFirstSectionOfSecondPart(int firstId) throws SQLException, ClassNotFoundException
	{
		int FirstDigit=track.getAvailableFirstDigitForSecondPart();
		if(FirstDigit>0)
		{
			String value=generateSecondSectionOfSecondPart(FirstDigit,firstId);
			if(value!=null)
			{
				return value;
			}
			else
			{
				return generateFirstSectionOfSecondPart(firstId);
			}
		}
		else
		{
			return null;
		}
	}
	
	
	private String generateSecondSectionOfSecondPart(int val,int firstId) throws SQLException, ClassNotFoundException
	{
		int secondDigit=track.getAvailableSecondDigitForSecondPart();
		if(secondDigit>0)
		{
			int chckValue=val*10+secondDigit;
			String value=generateThirdSectionOfSecondPart(chckValue,firstId);
			if(value!=null)
			{
				return value;
			}
			else
			{
				return generateSecondSectionOfSecondPart(val,firstId);
			}
		}
		else
		{
			return null;
		}
	}
	
	private String generateThirdSectionOfSecondPart(int val,int firstId) throws SQLException, ClassNotFoundException
	{
		int thirdDigit=track.getAvailableThirdDigitForSecondPart();
		if(thirdDigit>0)
		{
			int isPresentId=chckWithDB.isPresentInSecondPart(val*10+thirdDigit);
			if(isPresentId>0)
			{
				int value=generateFirstSectionOfThirdpart(isPresentId);
			    if(value>0)
			    {
			    	chckWithDB.insertNumberInSecondTable(value, firstId);
			    	return convertIntToString(val*10+thirdDigit)+"-"+convertIntToString(value);
			    }
			    else
			    {
			    	return generateThirdSectionOfSecondPart(val,firstId);
			    }	
			}
			else
			{
				// Generate a random Number for Third Part
				int value=val*10+thirdDigit;
				int getId=chckWithDB.insertNumberInSecondTable(value, firstId);
				int thirdValue=generator.assignThirdRandonNumber();
				System.out.println("generated values third : "+thirdValue);
				int getThirdId=chckWithDB.insertNumberInThirdTable(thirdValue, getId);
				if(getId>0&&getThirdId>0)
				{
					return convertIntToString(value)+"-"+convertIntToString(thirdValue);
				}
				else
				{
					return null;
				}
			}
		}
		else
		{
			return null;
		}
	}
	
	
	private int generateFirstSectionOfThirdpart(int scndId) throws SQLException, ClassNotFoundException
	{
		int firstDigit=track.getAvailableFirstDigitForThirdPart();
		if(firstDigit>0)
		{
			System.out.println("passing first : "+firstDigit);
			int value= generateSecondSectionOfThirdpart(firstDigit,scndId);
			if(value>0)
			{
				System.out.println("First value : "+(firstDigit+value));
				return value;
			}
			else
			{
				return generateFirstSectionOfThirdpart(scndId);
			}
		}
		else
		{
			return -1;
		}
		
	}
	
	private int generateSecondSectionOfThirdpart(int val,int scndId) throws SQLException, ClassNotFoundException
	{
		int secondDigit=track.getAvailableSecondDigitForThirdPart();
		if(secondDigit>0)
		{
			int vals=val*10+secondDigit;
			System.out.println("passing second : "+vals);
			int value= generateThirdSectionOfThirdPart(vals,scndId);
			if(value>0)
			{
				System.out.println("Second value : "+(vals+value));
				return value;
			}
			else
			{
				return generateSecondSectionOfThirdpart(val,scndId);
			}
		}
		else
		{
			return -1;
		}
		
	}
	
	
	private int generateThirdSectionOfThirdPart(int val,int scndId) throws SQLException, ClassNotFoundException
	{
		int lastDigit=track.getAvailableThirdDigitForThirdPart();
		if(lastDigit>0)
		{
			int chckValue=(val*10+lastDigit)*10+1;
			boolean[] vals=new boolean[9];
			int index=0,res=-1;
			
			System.out.println("checking valuye : "+chckValue);
			int[] nums=chckWithDB.getAvalilableNumbers(chckValue,scndId);
			if(nums!=null)
			{
				while(index<10&&nums[index]!=0)
				{
					System.out.println("Here");
					vals[((nums[index]%10)-1)]=true;
					index++;
				}
				for(int i=0;i<9;i++)
				{
					if(!vals[i])
					{
						res=(chckValue/10)*10+(i+1);
						break;
					}
				}
				if(res>0)
				{
					System.out.println("Third value : "+res);
					chckWithDB.insertNumberInThirdTable(res, scndId);
					return res;
				}
				else
				{
					return generateThirdSectionOfThirdPart(val,scndId);
				}
			}
			else
			{
				int thrdId=chckWithDB.insertNumberInThirdTable(chckValue, scndId);
				if(thrdId>0)
				{
					return chckValue;	
				}
				else
				{
					return -1;
				}
			}
			
		}
		else
		{
			
			return -1;
		}
		
	}
}
