package com.assignnewnumber.delegate;

import java.util.Random;

public class AssignRandomNumberDelegate {

	Random generator=new Random();
	
	public int assignFirstPartRandomNumber()
	{
	  	return generateThreeDigitRandomNumber();
	}
	
	private int generateThreeDigitRandomNumber()
	{
		int value=this.generator.nextInt(9)+1;
		int ind=2;
		while(ind!=0)
		{
			ind--;
			value*=10;
			value+=this.generator.nextInt(9)+1;
		}
       return value;		
	}
	
	public int assignSecondRandonNumber()
	{
		return generateThreeDigitRandomNumber();
	}
	
	public int assignThirdRandonNumber()
	{
	  return generateFourDigitNumber();	
	}
	
	private int generateFourDigitNumber()
	{
		int value=this.generator.nextInt(9)+1;
		int ind=3;
		while(ind!=0)
		{
			value*=10;
			value+=this.generator.nextInt(9)+1;
			ind--;
		}
	   return value;	
	}
	
}
