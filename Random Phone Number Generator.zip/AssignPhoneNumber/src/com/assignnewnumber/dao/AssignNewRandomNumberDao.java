package com.assignnewnumber.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.assignnewnumber.delegate.AssignRandomNumberDelegate;
import com.assignnewnumber.helper.DBConnection;
import com.assignnewnumber.helper.SQLQueries;

public class AssignNewRandomNumberDao {

	Connection con=null;
	 PreparedStatement stmt=null;
	 ResultSet rs=null;
	AssignRandomNumberDelegate generator=new  AssignRandomNumberDelegate();
	
	public AssignNewRandomNumberDao() throws ClassNotFoundException, SQLException
	{
		con=DBConnection.getConnection();
	}
	
	
	
	public int[] getAvalilableNumbers(int num,int scId) throws SQLException
	{
		int[] nums=null;
		int index=0;
		String query=SQLQueries.getAvailableNumbersInThirdTable;
		stmt=con.prepareStatement(query);
		stmt.setInt(1, num);
		stmt.setInt(2,scId);
		rs=stmt.executeQuery();
		if(rs.next())
		{
			nums=new int[9];
			nums[index++]=rs.getInt(1);
			while(rs.next())
			{
				nums[index++]=rs.getInt(1);
			}	
		}
		return nums;
	}
	
	private String getQueryToFetch(int ind)
	{
		if(ind==0)
		{
			return SQLQueries.getAvailableNumbersInFirstTable;
		}
		else if(ind==1)
		{
			return SQLQueries.getAvailableNumbersInSecondTable;
		}
		else if(ind==2)
		{
			return SQLQueries.getAvailableNumbersInThirdTable;
		}
		else
		{
			return null;
		}
	}
	
	private int getNumID(int num,String query) throws SQLException
	{
		int id=-1;
		stmt=con.prepareStatement(query);
		stmt.setInt(1, num);
		rs=stmt.executeQuery();
		if(rs.next())
		{
			id=rs.getInt(1);
		}
		return id;
	}
	
	private String getQueryToFetchID(int ind)
	{
		if(ind==0)
		{
		  return SQLQueries.getNumberIDFromFirstPart;	
		}
		else if(ind==1)
		{
			return SQLQueries.getNumberIDFromSecondPart;
		}
		return null;
	}
	
	public boolean insertFromFirstTable(int first,int second,int third) throws ClassNotFoundException, SQLException
	{
		int first_id=insertNumberInFirstTable(first);
		if(first_id>0)
		{
			int second_id=insertNumberInSecondTable(second, first_id);
			if(second_id>0)
			{
				int third_update=insertNumberInThirdTable(third, second_id);
				return (third_update>0)?true:false;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	
	
	public boolean insertFromSecondTable(int first,int second,int third) throws SQLException, ClassNotFoundException
	{
		String query=getQueryToFetch(0);
		int first_id=getNumID(first, query);
		if(first_id>0)
		{
			int second_id=insertNumberInSecondTable(second, first_id);
			if(second_id>0)
			{
				int third_update=insertNumberInThirdTable(third, second_id);
				return (third_update>0)?true:false;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	
	public boolean insertFromThirdTable(int first,int second,int third) throws SQLException, ClassNotFoundException
	{
		String query=getQueryToFetch(0);
		int first_id=getNumID(first, query);
		if(first_id>0)
		{
			query=getQueryToFetch(1);
			int second_id=getNumID(second, query);
			if(second_id>0)
			{
				int third_update=insertNumberInThirdTable(third, second_id);
				return (third_update>0)?true:false;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	
	public int insertNumberInFirstTable(int num) throws ClassNotFoundException, SQLException
	{
		stmt=con.prepareStatement(SQLQueries.insertInFirsttable);
		stmt.setInt(1, num);
		
		int rslt=stmt.executeUpdate();
		
		if(rslt>0)
		{
			String query=getQueryToFetchID(0);
            int id=getNumID(num, query);
            return id;
		}
		else
		{
			return -1;
		}
	}
	
	public int insertNumberInSecondTable(int num,int first_id) throws ClassNotFoundException, SQLException
	{
		stmt=con.prepareStatement(SQLQueries.insertInSecondtable);
		stmt.setInt(1, num);
		stmt.setInt(2, first_id);
		int rslt=stmt.executeUpdate();
		
		if(rslt>0)
		{
			String query=getQueryToFetchID(1);
			int id=getNumID(num, query);
			return id;
		}
		else
		{
			return -1;
		}
		
		
	}
	
	public int insertNumberInThirdTable(int num,int second_id) throws ClassNotFoundException, SQLException
	{
		stmt=con.prepareStatement(SQLQueries.insertInThirdtable);
		stmt.setInt(1, num);
		stmt.setInt(2, second_id);
		int rslt=stmt.executeUpdate();
		return (rslt>0)?rslt:-1;
	}
	public int isPresentInFirstPart(int num) throws SQLException
	{
		int res=-1;
	    stmt= con.prepareStatement(SQLQueries.isPresentNumberInFirstPart);
	    stmt.setInt(1, num);
	    ResultSet rs=stmt.executeQuery();
	    if(rs.next())
	    {
	    	res=rs.getInt(1);
	    }
		return res;
	}
	
	public int isPresentInSecondPart(int num) throws SQLException
	{
		int res=-1;
		stmt= con.prepareStatement(SQLQueries.isPresentNumberInSecondPart);
		    stmt.setInt(1, num);
		    ResultSet rs=stmt.executeQuery();
		    if(rs.next())
		    {
		    	res=rs.getInt(1);
		    }
		return res;
	}
	
	public int isPresentInThirdPart(int num) throws SQLException
	{
		int res=-1;
		stmt= con.prepareStatement(SQLQueries.isPresentNumberInThirdPart);
		    stmt.setInt(1, num);
		    ResultSet rs=stmt.executeQuery();
		    if(rs.next())
		    {
		    	res=rs.getInt(1);
		    }
		return res;
	}
	
}
