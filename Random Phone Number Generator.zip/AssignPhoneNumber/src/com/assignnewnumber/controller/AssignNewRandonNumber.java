package com.assignnewnumber.controller;


import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.assignnewnumber.service.AssignRandomNumberService;

@Controller
public class AssignNewRandonNumber {

	AssignRandomNumberService generator=null;
	
	public AssignNewRandonNumber() throws ClassNotFoundException, SQLException
	{
		generator=new AssignRandomNumberService();
	}
	
	@RequestMapping("generateNewPhoneNumber.htm")
	public ModelAndView assignNewRandomNumber(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		String number=null;
		number=generator.assignNewRandomNumber();
		System.out.println(number);
		mv.addObject("number",number);
		mv.setViewName("/Success.jsp");
	    return mv;
	}
	
	@RequestMapping("specificnumber.htm")
	public ModelAndView alocateASpecificNumber(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView(); 
				
		String number=req.getParameter("number");
		if(number==null||number.equals(""))
		{
			mv.addObject("number","Please fill the Phone Number");
		}
		else
		{
			mv.addObject("number",generator.alocateASpecificNumber(number));
		}
		mv.setViewName("/ManualPhoneNumber.jsp");
		return mv;
	}
	
	@RequestMapping("init.htm")
	public ModelAndView initPage(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		mv.addObject("number",null);
		mv.setViewName("/Success.jsp");
		return mv;
	}
	
	//
	@RequestMapping("manualnumber.htm")
	public ModelAndView alocateASpecificNumberInit(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		mv.addObject("number",null);
		mv.setViewName("/ManualPhoneNumber.jsp");
		return mv;
	}
}
